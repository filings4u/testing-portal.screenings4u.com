# Screenings4u Testing Management Portal — Management Shell Reset

This package restarts `testing-portal.screenings4u.com` on the same management portal shell used by Training, DOT, and NON-DOT management.

## Rules
- Enterprise selector is the only login/entry path.
- Only `dashboard.html` is a dashboard.
- Every other page is a records or management page.
- No customer-portal shell or customer navigation is used.
- Management forms live on dedicated pages, not modals.
- Modals are reserved for confirmations/session security.

## Live backend boundaries
- `testing-management-context`
- `testing-management-read`
- `testing-operations-management`
- `testing-case-management`

## Implemented modules
1. Dashboard
2. Testing Operations
3. Cases


## Results module
- results.html
- result.html
- result-documents.html
- result-upload.html
- result-history.html
Backend: testing-result-management


## Donor Passes module
- donor-passes.html
- donor-pass-create.html
- donor-pass.html
- donor-pass-delivery.html
- donor-pass-history.html
Backend: testing-donor-pass-management


## Service Requests module
- service-requests.html
- service-request-create.html
- service-request.html
- service-request-customer.html
- service-request-assignment.html
- service-request-history.html
Backend: testing-service-request-management


## Work Orders module
- work-orders.html
- work-order-create.html
- work-order.html
- work-order-assignment.html
- work-order-services.html
- work-order-customer.html
- work-order-history.html
Backend: testing-work-order-management


## Customers & Portal Access module
- customers.html
- customer.html
- customer-portal-access.html
- customer-orders.html
- customer-cases.html
- customer-organizations.html
- customer-history.html
Backend: testing-customer-management


## Providers module
- providers.html
- provider-create.html
- provider.html
- provider-services.html
- provider-locations.html
- provider-contacts.html
- provider-history.html
Backend: testing-provider-management
Provider sources: compliance_collection_sites, compliance_laboratories, compliance_mros
Collector Network intentionally remains separate.


## Background Checks module
- background-checks.html
- background-check-create.html
- background-check.html
- background-check-candidate.html
- background-check-package.html
- background-check-events.html

Backend:
- testing-background-check-management
- checkr-webhook

Checkr credentials remain server-side. Expected secrets:
- CHECKR_API_KEY
- CHECKR_ENVIRONMENT (production or staging)
- CHECKR_WEBHOOK_SECRET (optional; falls back to CHECKR_CLIENT_SECRET or CHECKR_API_KEY for signature validation)

Hosted invitation flow is used so sensitive candidate PII and consent are collected by Checkr, not by this management portal.


## Labcorp OTS Orders module
- labcorp-orders.html
- labcorp-order-create.html
- labcorp-order.html
- labcorp-order-registration.html
- labcorp-order-sites.html
- labcorp-order-results.html
- labcorp-order-events.html

Backends:
- testing-labcorp-order-management
- labcorp-ots-callback
- testing-order-management v2 returns linked Labcorp orders

Expected server-side Labcorp settings:
- LABCORP_OTS_ENDPOINT
- LABCORP_OTS_USER
- LABCORP_OTS_PASSWORD
- LABCORP_CALLBACK_USER
- LABCORP_CALLBACK_PASSWORD

The supplied Labcorp WSDL uses localhost service addresses; production URL is intentionally not hardcoded.
Commercial Testing orders remain separate from operational Labcorp registrations.


## Documents module
- documents.html
- document-upload.html
- document.html
- document-history.html

Backend:
- testing-document-management

Document sources:
- testing_private_documents
- testing_case_documents
- testing_labcorp_orders COC storage

No duplicate file store is created. General/customer/employer uploads go to testing_private_documents. Case/result documents remain owned by the Testing Case/Results modules. Labcorp COC files remain owned by Labcorp Orders.

## Labcorp certification environment note
Labcorp OTS donor-registration certification endpoint supplied by Labcorp:
https://services-cert.labcorpsolutions.com/webservice/services/LabcorpOTS

For inbound Results / Statuses / COC certification, Labcorp requires the Testing callback URL plus a callback User ID and password. Production endpoint and production credentials remain server-side and are not hardcoded into frontend assets.


## Catalog module
- catalog.html
- catalog-create.html
- catalog-service.html
- catalog-pricing.html
- catalog-fulfillment.html
- catalog-website.html
- catalog-history.html

Backend:
- testing-catalog-management

Source of truth:
- services
- service_prices
- testing_catalog_events

Catalog changes update the same service records used by screenings4u.com.
Pricing changes preserve effective price history rather than overwriting the previous price.
Labcorp panel IDs must be supplied/approved by Labcorp and are never guessed.


## Website / Blog module
Pages:
- website.html
- website-pages.html
- website-page-create.html
- website-page.html
- website-history.html
- blog.html
- blog-create.html
- blog-post.html
- blog-media.html

Backends:
- testing-website-management
- testing-blog-management

Sources of truth:
- testing_website_pages (screenings4u.com page registry / managed metadata)
- blog_posts where site_code='screenings4u'
- testing_website_events
- testing-blog-images storage bucket

The current screenings4u.com blog reads published blog_posts directly, so blog publishing is live-data publishing.
Static HTML pages are not falsely treated as deployed when only the management database record changes.
